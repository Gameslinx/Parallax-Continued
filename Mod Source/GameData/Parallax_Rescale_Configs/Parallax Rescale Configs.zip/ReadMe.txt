1. Extract the folder of choice to your GameData folder.
For example, if you would like to use 2.5x scale, extract 'Parallax_Rescale_2.5' to your GameData folder